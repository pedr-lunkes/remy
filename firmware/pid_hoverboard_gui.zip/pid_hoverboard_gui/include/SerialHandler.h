#pragma once
#include <QObject>
#include <QSerialPort>
#include <QTimer>

class SerialHandler : public QObject {
    Q_OBJECT

public:
    explicit SerialHandler(QObject *parent = nullptr);
    void connectPort(const QString &portName, int baudRate = 115200);


    void resetIntegrals(); //add

    void writeData(const QByteArray &data);



    // ✅ NOVA VERSÃO — aceita também direção (para joystick)
    void sendPWM(int pwm1, int dir1, int pwm2, int dir2);

    // ✅ Função PID existente (mantida)
    float setpoint1 = 0, setpoint2 = 0;
    float Kp1 = 0.2f, Ki1 = 0.11f, Kd1 = 0.0f;
    float Kp2 = 0.2f, Ki2 = 0.11f, Kd2 = 0.0f;

signals:
    void rpmUpdated(float rpm1, float rpm2);

private slots:
    void readData();
    void updatePID();

private:
    QSerialPort serial;
    QTimer pidTimer;

    float rpm1 = 0, rpm2 = 0;
    float integral1 = 0, integral2 = 0;
    float prevError1 = 0, prevError2 = 0;

    // ⚠️ Mantida a versão interna antiga (sem direção explícita)
    void sendPWM(int pwm1, int pwm2);
};
