#include "my_bot_hardware/bot_system.hpp"

#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <cstring>
#include <sstream>


#include "pluginlib/class_list_macros.hpp"
PLUGINLIB_EXPORT_CLASS(my_bot_hardware::BotSystem, hardware_interface::SystemInterface)

namespace my_bot_hardware
{

using hardware_interface::CallbackReturn;
using hardware_interface::return_type;

CallbackReturn BotSystem::on_init(const hardware_interface::HardwareInfo & info)
{
  if (SystemInterface::on_init(info) != CallbackReturn::SUCCESS) {
    return CallbackReturn::ERROR;
  }

  // Lê parâmetros do URDF <param name="port"> etc.
  for (const auto & param : info_.hardware_parameters) {
    if (param.first == "port") {
      port_name_ = param.second;
    } else if (param.first == "baudrate") {
      baudrate_ = std::stoi(param.second);
    }
  }

  RCLCPP_INFO(rclcpp::get_logger("BotSystem"), 
    "Using serial port: %s, baudrate: %d",
    port_name_.c_str(), baudrate_);

  return CallbackReturn::SUCCESS;
}

std::vector<hardware_interface::StateInterface> BotSystem::export_state_interfaces()
{
  std::vector<hardware_interface::StateInterface> state_interfaces;

  // ======== SEU ROBÔ: NAMES CORRETOS ========
  state_interfaces.emplace_back("rev1", hardware_interface::HW_IF_POSITION, &pos_left_rad_);
  state_interfaces.emplace_back("rev1", hardware_interface::HW_IF_VELOCITY, &vel_left_rad_s_);

  state_interfaces.emplace_back("rev2", hardware_interface::HW_IF_POSITION, &pos_right_rad_);
  state_interfaces.emplace_back("rev2", hardware_interface::HW_IF_VELOCITY, &vel_right_rad_s_);
  // ==========================================

  return state_interfaces;
}

std::vector<hardware_interface::CommandInterface> BotSystem::export_command_interfaces()
{
  std::vector<hardware_interface::CommandInterface> command_interfaces;

  // ======== SEU ROBÔ: NAMES CORRETOS ========
  command_interfaces.emplace_back("rev1", hardware_interface::HW_IF_VELOCITY, &cmd_left_rad_s_);
  command_interfaces.emplace_back("rev2", hardware_interface::HW_IF_VELOCITY, &cmd_right_rad_s_);
  // ==========================================

  return command_interfaces;
}

CallbackReturn BotSystem::on_activate(const rclcpp_lifecycle::State &)
{
  if (!openSerialPort()) {
    RCLCPP_ERROR(rclcpp::get_logger("BotSystem"), "Failed to open serial port");
    return CallbackReturn::ERROR;
  }

  last_read_time_ = rclcpp::Time(0, 0, RCL_SYSTEM_TIME);
  return CallbackReturn::SUCCESS;
}

CallbackReturn BotSystem::on_deactivate(const rclcpp_lifecycle::State &)
{
  closeSerialPort();
  return CallbackReturn::SUCCESS;
}

return_type BotSystem::read(const rclcpp::Time & time,
                            const rclcpp::Duration & period)
{
  (void)time;
  (void)period;

  double rpmL, rpmR;
  if (readRPMFromSerial(rpmL, rpmR)) {
    rpm_left_meas_  = rpmL;
    rpm_right_meas_ = rpmR;

    // converte RPM -> rad/s
    const double TWO_PI = 6.283185307179586;
    vel_left_rad_s_  = (rpm_left_meas_  * TWO_PI) / 60.0;
    vel_right_rad_s_ = (rpm_right_meas_ * TWO_PI) / 60.0;

    // integra posição
    double dt = period.seconds();
    pos_left_rad_  += vel_left_rad_s_  * dt;
    pos_right_rad_ += vel_right_rad_s_ * dt;
  }

  return return_type::OK;
}

return_type BotSystem::write(const rclcpp::Time & time,
                             const rclcpp::Duration & period)
{
  (void)time;
  (void)period;

  const double TWO_PI = 6.283185307179586;
  double rpm_left_cmd  = (cmd_left_rad_s_  * 60.0) / TWO_PI;
  double rpm_right_cmd = (cmd_right_rad_s_ * 60.0) / TWO_PI;

  sendVelocityRPM(rpm_left_cmd, rpm_right_cmd);
  return return_type::OK;
}

// ===================== Serial helpers =====================

bool BotSystem::openSerialPort()
{
  serial_fd_ = open(port_name_.c_str(), O_RDWR | O_NOCTTY | O_NONBLOCK);
  if (serial_fd_ < 0) {
    RCLCPP_ERROR(rclcpp::get_logger("BotSystem"),
                 "Error opening serial port %s: %s",
                 port_name_.c_str(), std::strerror(errno));
    return false;
  }

  termios tty{};
  if (tcgetattr(serial_fd_, &tty) != 0) {
    RCLCPP_ERROR(rclcpp::get_logger("BotSystem"),
                 "Error from tcgetattr: %s", std::strerror(errno));
    return false;
  }

  cfmakeraw(&tty);

  speed_t speed = B115200;
  if (baudrate_ == 115200) speed = B115200;

  cfsetispeed(&tty, speed);
  cfsetospeed(&tty, speed);

  tty.c_cflag |= (CLOCAL | CREAD);
  tty.c_cflag &= ~CSIZE;
  tty.c_cflag |= CS8;
  tty.c_cflag &= ~PARENB;
  tty.c_cflag &= ~CSTOPB;
  tty.c_cflag &= ~CRTSCTS;

  tty.c_cc[VMIN] = 0;
  tty.c_cc[VTIME] = 0;

  if (tcsetattr(serial_fd_, TCSANOW, &tty) != 0) {
    RCLCPP_ERROR(rclcpp::get_logger("BotSystem"),
                 "Error from tcsetattr: %s", std::strerror(errno));
    return false;
  }

  return true;
}

void BotSystem::closeSerialPort()
{
  if (serial_fd_ >= 0) {
    close(serial_fd_);
    serial_fd_ = -1;
  }
}

bool BotSystem::sendVelocityRPM(double rpm_left, double rpm_right)
{
  if (serial_fd_ < 0) return false;

  std::ostringstream ss;
  ss << "VEL," << rpm_left << "," << rpm_right << "\n";
  std::string msg = ss.str();
  ssize_t n = write(serial_fd_, msg.c_str(), msg.size());
  return (n == (ssize_t)msg.size());
}

bool BotSystem::readRPMFromSerial(double &rpm_left, double &rpm_right)
{
  if (serial_fd_ < 0) return false;

  char buf[256];
  ssize_t n = read(serial_fd_, buf, sizeof(buf) - 1);
  if (n <= 0) {
    return false;
  }
  buf[n] = '\0';
  std::string data(buf);

  std::size_t pos = data.find("RPM,");
  if (pos == std::string::npos) {
    return false;
  }

  std::string line = data.substr(pos);
  std::size_t end = line.find('\n');
  if (end != std::string::npos) {
    line = line.substr(0, end);
  }

  std::stringstream ss(line.substr(4));
  std::string part1, part2;
  if (std::getline(ss, part1, ',') && std::getline(ss, part2, ',')) {
    try {
      rpm_left  = std::stod(part1);
      rpm_right = std::stod(part2);
      return true;
    } catch (...) {
      return false;
    }
  }

  return false;
}

}  // namespace my_bot_hardware

#include "pluginlib/class_list_macros.hpp"
PLUGINLIB_EXPORT_CLASS(my_bot_hardware::BotSystem, hardware_interface::SystemInterface)
